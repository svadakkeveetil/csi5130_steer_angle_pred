#ifndef DBW_MKZ_MSGS_MESSAGE_TURNSIGNALCMD_H
#define DBW_MKZ_MSGS_MESSAGE_TURNSIGNALCMD_H


#include <dbw_mkz_msgs/MiscCmd.h>

namespace dbw_mkz_msgs
{

// Backwards compatibility with old message type
typedef MiscCmd TurnSignalCmd;

} // namespace dbw_mkz_msgs

#endif // DBW_MKZ_MSGS_MESSAGE_TURNSIGNALCMD_H
